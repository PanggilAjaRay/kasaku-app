import React, { useState, useEffect, createContext, useContext } from 'react';
import { MemoryRouter, Routes, Route, useLocation, Navigate, Link } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Receipt, 
  ArrowRightLeft, 
  Settings, 
  User, 
  Briefcase, 
  Utensils, 
  Factory, 
  Calendar, 
  Users,
  AlertTriangle,
  Lock,
  Menu
} from 'lucide-react';
import { LicenseData, NavItem, Addons, Transaction, Invoice, Client, Project, Task, UserProfile, InvoiceSettings, RawMaterial, BOM, ProductionOrder, MenuItem, POSOrder, CalendarEvent } from './types';
import Dashboard from './pages/Dashboard';
import Transactions from './pages/Transactions';
import Invoices from './pages/Invoices';
import InvoicePrint from './pages/InvoicePrint';
import ReceiptPrint from './pages/ReceiptPrint';
import Profile from './pages/Profile';
import SettingsPage from './pages/Settings';
import Manufacturing from './pages/Manufacturing';
import Restaurant from './pages/Restaurant';
import CRM from './pages/CRM';
import Projects from './pages/Projects';
import CalendarPage from './pages/Calendar';

// --- MOCK DATA FOR INITIALIZATION ---
const INITIAL_TRANSACTIONS: Transaction[] = [
  { id: 'TRX-001', date: '2023-10-25', description: 'Pembayaran Invoice #INV-001', amount: 5000000, type: 'income', category: 'Penjualan' },
  { id: 'TRX-002', date: '2023-10-24', description: 'Beli Kertas A4', amount: 45000, type: 'expense', category: 'Perlengkapan Kantor' },
  { id: 'TRX-003', date: '2023-10-22', description: 'Biaya Listrik Oktober', amount: 1200000, type: 'expense', category: 'Utilitas' },
];

const INITIAL_INVOICES: Invoice[] = [
  { id: 'INV-2023-001', customerName: 'PT Teknologi Maju', date: '2023-10-25', dueDate: '2023-11-25', amount: 12500000, status: 'PENDING', items: [] },
  { id: 'INV-2023-002', customerName: 'CV Berkah Abadi', date: '2023-10-20', dueDate: '2023-11-20', amount: 3200000, status: 'PAID', items: [] },
];

const INITIAL_CLIENTS: Client[] = [
  { id: 'C-001', name: 'Budi Santoso', company: 'PT Teknologi Maju', email: 'budi@tekmaju.com', phone: '081234567890', status: 'ACTIVE', totalRevenue: 45000000 },
  { id: 'C-002', name: 'Siti Aminah', company: 'CV Berkah Abadi', email: 'siti@berkah.co.id', phone: '081987654321', status: 'ACTIVE', totalRevenue: 12500000 },
];

const INITIAL_PROJECTS: Project[] = [
  { id: 'P-001', name: 'Website Redesign', clientId: 'C-001', clientName: 'PT Teknologi Maju', status: 'IN_PROGRESS', progress: 75, dueDate: '2023-11-15', budget: 15000000 },
];

const INITIAL_PROFILE: UserProfile = {
  companyName: 'PT Maju Bersama',
  adminName: 'Budi Santoso',
  email: 'admin@majubersama.com'
};

const INITIAL_INVOICE_SETTINGS: InvoiceSettings = {
  paymentInfo: "Bank BCA: 123-456-7890\na/n PT Maju Bersama\n\nBank Mandiri: 987-654-3210\na/n PT Maju Bersama",
  hideWatermark: false,
  footerNote: "Terima kasih atas kepercayaan Anda.",
  signatureName: "Budi Santoso",
  city: "Jakarta",
  taxRate: 11 // Default 11%
};

const INITIAL_MENU: MenuItem[] = [
  { id: 'M01', name: 'Nasi Goreng Spesial', category: 'MAKANAN', price: 25000, cogs: 12000 },
  { id: 'M02', name: 'Ayam Bakar Madu', category: 'MAKANAN', price: 30000, cogs: 15000 },
  { id: 'M03', name: 'Mie Goreng Jawa', category: 'MAKANAN', price: 22000, cogs: 10000 },
  { id: 'M04', name: 'Es Teh Manis', category: 'MINUMAN', price: 5000, cogs: 1500 },
  { id: 'M05', name: 'Kopi Susu Gula Aren', category: 'MINUMAN', price: 18000, cogs: 6000 },
  { id: 'M06', name: 'Kentang Goreng', category: 'CEMILAN', price: 15000, cogs: 5000 },
];

// Mock Manufacturing Data
const INITIAL_MATERIALS: RawMaterial[] = [
  { id: 'RM-001', name: 'Kayu Jati Solid', unit: 'meter', costPerUnit: 150000, currentStock: 45, minStockAlert: 10 },
  { id: 'RM-002', name: 'Cat Varnish', unit: 'kaleng', costPerUnit: 85000, currentStock: 12, minStockAlert: 5 },
  { id: 'RM-003', name: 'Sekrup Baja 5cm', unit: 'pcs', costPerUnit: 500, currentStock: 1500, minStockAlert: 200 },
];

const INITIAL_BOMS: BOM[] = [
  { 
    id: 'BOM-001', 
    productName: 'Meja Makan Jati (Standard)', 
    estimatedCost: 650000,
    items: [
      { materialId: 'RM-001', qtyRequired: 3.5 },
      { materialId: 'RM-002', qtyRequired: 1 },
      { materialId: 'RM-003', qtyRequired: 24 }
    ]
  },
];

const INITIAL_ORDERS: ProductionOrder[] = [
  { id: 'PO-2310-01', bomId: 'BOM-001', date: '2023-10-26', qtyProduced: 10, totalCost: 6500000, status: 'IN_PROGRESS' },
];

// --- GLOBAL DATA CONTEXT ---
interface DataContextType {
  userProfile: UserProfile;
  updateUserProfile: (p: UserProfile) => void;
  invoiceSettings: InvoiceSettings;
  updateInvoiceSettings: (s: InvoiceSettings) => void;
  transactions: Transaction[];
  addTransaction: (t: Transaction) => void;
  updateTransaction: (t: Transaction) => void;
  deleteTransaction: (id: string) => void;
  invoices: Invoice[];
  addInvoice: (i: Invoice) => void;
  updateInvoice: (i: Invoice) => void;
  deleteInvoice: (id: string) => void;
  
  // Plus Advance (CRM, Projects, Calendar)
  clients: Client[];
  addClient: (c: Client) => void;
  updateClient: (c: Client) => void;
  deleteClient: (id: string) => void;
  
  projects: Project[];
  addProject: (p: Project) => void;
  updateProject: (p: Project) => void;
  deleteProject: (id: string) => void;
  
  tasks: Task[];
  addTask: (t: Task) => void;
  updateTask: (t: Task) => void;
  deleteTask: (id: string) => void;

  customEvents: CalendarEvent[];
  addCustomEvent: (e: CalendarEvent) => void;
  deleteCustomEvent: (id: string) => void;
  
  // Manufacturing
  materials: RawMaterial[];
  addMaterial: (m: RawMaterial) => void;
  updateMaterial: (m: RawMaterial) => void;
  deleteMaterial: (id: string) => void;
  boms: BOM[];
  addBOM: (b: BOM) => void;
  updateBOM: (b: BOM) => void;
  deleteBOM: (id: string) => void;
  productionOrders: ProductionOrder[];
  addProductionOrder: (o: ProductionOrder) => void;
  updateProductionOrder: (o: ProductionOrder) => void; // General update
  completeProductionOrder: (id: string) => { success: boolean, message: string }; // Logic to deduct stock

  // Restaurant
  menuItems: MenuItem[];
  addMenuItem: (m: MenuItem) => void;
  updateMenuItem: (m: MenuItem) => void;
  deleteMenuItem: (id: string) => void;
  menuCategories: string[];
  addCategory: (c: string) => void;
  deleteCategory: (c: string) => void;
  posOrders: POSOrder[];
  addPOSOrder: (o: POSOrder) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) throw new Error('useData must be used within a DataProvider');
  return context;
};

const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize state
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('kasaku_profile');
    return saved ? JSON.parse(saved) : INITIAL_PROFILE;
  });

  const [invoiceSettings, setInvoiceSettings] = useState<InvoiceSettings>(() => {
    const saved = localStorage.getItem('kasaku_invoice_settings');
    return saved ? JSON.parse(saved) : INITIAL_INVOICE_SETTINGS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('kasaku_transactions');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    const saved = localStorage.getItem('kasaku_invoices');
    return saved ? JSON.parse(saved) : INITIAL_INVOICES;
  });

  const [clients, setClients] = useState<Client[]>(() => {
    const saved = localStorage.getItem('kasaku_clients');
    return saved ? JSON.parse(saved) : INITIAL_CLIENTS;
  });

  const [projects, setProjects] = useState<Project[]>(() => {
    const saved = localStorage.getItem('kasaku_projects');
    return saved ? JSON.parse(saved) : INITIAL_PROJECTS;
  });

  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('kasaku_tasks');
    return saved ? JSON.parse(saved) : [];
  });

  const [customEvents, setCustomEvents] = useState<CalendarEvent[]>(() => {
    const saved = localStorage.getItem('kasaku_custom_events');
    return saved ? JSON.parse(saved) : [];
  });

  // Manufacturing State
  const [materials, setMaterials] = useState<RawMaterial[]>(() => {
    const saved = localStorage.getItem('kasaku_materials');
    return saved ? JSON.parse(saved) : INITIAL_MATERIALS;
  });
  const [boms, setBoms] = useState<BOM[]>(() => {
    const saved = localStorage.getItem('kasaku_boms');
    return saved ? JSON.parse(saved) : INITIAL_BOMS;
  });
  const [productionOrders, setProductionOrders] = useState<ProductionOrder[]>(() => {
    const saved = localStorage.getItem('kasaku_orders');
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  // Restaurant State
  const [menuItems, setMenuItems] = useState<MenuItem[]>(() => {
    const saved = localStorage.getItem('kasaku_menu');
    return saved ? JSON.parse(saved) : INITIAL_MENU;
  });
  const [menuCategories, setMenuCategories] = useState<string[]>(() => {
    const saved = localStorage.getItem('kasaku_categories');
    return saved ? JSON.parse(saved) : ['MAKANAN', 'MINUMAN', 'CEMILAN'];
  });
  const [posOrders, setPosOrders] = useState<POSOrder[]>(() => {
    const saved = localStorage.getItem('kasaku_pos_orders');
    return saved ? JSON.parse(saved) : [];
  });


  // Persist to LocalStorage
  useEffect(() => localStorage.setItem('kasaku_profile', JSON.stringify(userProfile)), [userProfile]);
  useEffect(() => localStorage.setItem('kasaku_invoice_settings', JSON.stringify(invoiceSettings)), [invoiceSettings]);
  useEffect(() => localStorage.setItem('kasaku_transactions', JSON.stringify(transactions)), [transactions]);
  useEffect(() => localStorage.setItem('kasaku_invoices', JSON.stringify(invoices)), [invoices]);
  
  useEffect(() => localStorage.setItem('kasaku_clients', JSON.stringify(clients)), [clients]);
  useEffect(() => localStorage.setItem('kasaku_projects', JSON.stringify(projects)), [projects]);
  useEffect(() => localStorage.setItem('kasaku_tasks', JSON.stringify(tasks)), [tasks]);
  useEffect(() => localStorage.setItem('kasaku_custom_events', JSON.stringify(customEvents)), [customEvents]);
  
  useEffect(() => localStorage.setItem('kasaku_materials', JSON.stringify(materials)), [materials]);
  useEffect(() => localStorage.setItem('kasaku_boms', JSON.stringify(boms)), [boms]);
  useEffect(() => localStorage.setItem('kasaku_orders', JSON.stringify(productionOrders)), [productionOrders]);

  useEffect(() => localStorage.setItem('kasaku_menu', JSON.stringify(menuItems)), [menuItems]);
  useEffect(() => localStorage.setItem('kasaku_categories', JSON.stringify(menuCategories)), [menuCategories]);
  useEffect(() => localStorage.setItem('kasaku_pos_orders', JSON.stringify(posOrders)), [posOrders]);

  // Action Helpers
  const updateUserProfile = (p: UserProfile) => setUserProfile(p);
  const updateInvoiceSettings = (s: InvoiceSettings) => setInvoiceSettings(s);

  const addTransaction = (t: Transaction) => setTransactions(prev => [t, ...prev]);
  const updateTransaction = (t: Transaction) => setTransactions(prev => prev.map(item => item.id === t.id ? t : item));
  const deleteTransaction = (id: string) => setTransactions(prev => prev.filter(item => item.id !== id));

  const addInvoice = (i: Invoice) => setInvoices(prev => [i, ...prev]);
  const updateInvoice = (i: Invoice) => setInvoices(prev => prev.map(item => item.id === i.id ? i : item));
  const deleteInvoice = (id: string) => setInvoices(prev => prev.filter(item => item.id !== id));

  // Plus Advance Actions
  const addClient = (c: Client) => setClients(prev => [c, ...prev]);
  const updateClient = (c: Client) => setClients(prev => prev.map(item => item.id === c.id ? c : item));
  const deleteClient = (id: string) => setClients(prev => prev.filter(item => item.id !== id));

  const addProject = (p: Project) => setProjects(prev => [p, ...prev]);
  const updateProject = (p: Project) => setProjects(prev => prev.map(item => item.id === p.id ? p : item));
  const deleteProject = (id: string) => {
    setProjects(prev => prev.filter(item => item.id !== id));
    // Also delete tasks associated with project
    setTasks(prev => prev.filter(t => t.projectId !== id));
  };
  
  const addTask = (t: Task) => setTasks(prev => [t, ...prev]);
  const updateTask = (t: Task) => setTasks(prev => prev.map(item => item.id === t.id ? t : item));
  const deleteTask = (id: string) => setTasks(prev => prev.filter(item => item.id !== id));

  const addCustomEvent = (e: CalendarEvent) => setCustomEvents(prev => [e, ...prev]);
  const deleteCustomEvent = (id: string) => setCustomEvents(prev => prev.filter(e => e.id !== id));

  // Manufacturing Actions
  const addMaterial = (m: RawMaterial) => setMaterials(prev => [m, ...prev]);
  const updateMaterial = (m: RawMaterial) => setMaterials(prev => prev.map(item => item.id === m.id ? m : item));
  const deleteMaterial = (id: string) => setMaterials(prev => prev.filter(item => item.id !== id));

  const addBOM = (b: BOM) => setBoms(prev => [b, ...prev]);
  const updateBOM = (b: BOM) => setBoms(prev => prev.map(item => item.id === b.id ? b : item));
  const deleteBOM = (id: string) => setBoms(prev => prev.filter(item => item.id !== id));

  const addProductionOrder = (o: ProductionOrder) => setProductionOrders(prev => [o, ...prev]);
  const updateProductionOrder = (o: ProductionOrder) => setProductionOrders(prev => prev.map(item => item.id === o.id ? o : item));

  const completeProductionOrder = (id: string): { success: boolean, message: string } => {
    const order = productionOrders.find(o => o.id === id);
    if (!order) return { success: false, message: 'Order tidak ditemukan' };
    if (order.status === 'COMPLETED') return { success: false, message: 'Order sudah selesai' };

    const bom = boms.find(b => b.id === order.bomId);
    if (!bom) return { success: false, message: 'Resep (BOM) tidak ditemukan' };

    // Check Stock First
    for (const item of bom.items) {
      const material = materials.find(m => m.id === item.materialId);
      if (!material) return { success: false, message: `Bahan baku ${item.materialId} tidak ditemukan` };
      
      const requiredQty = item.qtyRequired * order.qtyProduced;
      if (material.currentStock < requiredQty) {
        return { success: false, message: `Stok ${material.name} tidak cukup. Butuh: ${requiredQty}, Ada: ${material.currentStock}` };
      }
    }

    // Deduct Stock
    const updatedMaterials = materials.map(m => {
      const bomItem = bom.items.find(bi => bi.materialId === m.id);
      if (bomItem) {
        const consumed = bomItem.qtyRequired * order.qtyProduced;
        return { ...m, currentStock: m.currentStock - consumed };
      }
      return m;
    });

    setMaterials(updatedMaterials);
    
    // Update Order Status
    updateProductionOrder({ ...order, status: 'COMPLETED' });

    return { success: true, message: 'Produksi selesai. Stok bahan baku telah dikurangi.' };
  };

  // Restaurant Actions
  const addMenuItem = (m: MenuItem) => setMenuItems(prev => [m, ...prev]);
  const updateMenuItem = (m: MenuItem) => setMenuItems(prev => prev.map(item => item.id === m.id ? m : item));
  const deleteMenuItem = (id: string) => setMenuItems(prev => prev.filter(item => item.id !== id));
  
  const addCategory = (c: string) => setMenuCategories(prev => [...prev, c]);
  const deleteCategory = (c: string) => setMenuCategories(prev => prev.filter(cat => cat !== c));
  
  const addPOSOrder = (o: POSOrder) => setPosOrders(prev => [o, ...prev]);

  return (
    <DataContext.Provider value={{
      userProfile, updateUserProfile,
      invoiceSettings, updateInvoiceSettings,
      transactions, addTransaction, updateTransaction, deleteTransaction,
      invoices, addInvoice, updateInvoice, deleteInvoice,
      
      clients, addClient, updateClient, deleteClient,
      projects, addProject, updateProject, deleteProject,
      tasks, addTask, updateTask, deleteTask,
      customEvents, addCustomEvent, deleteCustomEvent,
      
      materials, addMaterial, updateMaterial, deleteMaterial,
      boms, addBOM, updateBOM, deleteBOM,
      productionOrders, addProductionOrder, updateProductionOrder, completeProductionOrder,
      menuItems, addMenuItem, updateMenuItem, deleteMenuItem,
      menuCategories, addCategory, deleteCategory,
      posOrders, addPOSOrder
    }}>
      {children}
    </DataContext.Provider>
  );
};

// --- LICENSE CONTEXT ---
interface LicenseContextType {
  license: LicenseData | null;
  loading: boolean;
  refreshLicense: () => void;
  updateAddon: (key: keyof Addons, value: boolean) => void;
  extendLicense: () => void;
}

const LicenseContext = createContext<LicenseContextType | undefined>(undefined);

export const useLicense = () => {
  const context = useContext(LicenseContext);
  if (!context) throw new Error('useLicense must be used within a LicenseProvider');
  return context;
};

const MOCK_LICENSE: LicenseData = {
  status: 'OK',
  plan: 'PRO',
  days_left: 6,
  addons: {
    manufacturing: false,
    restaurant: false,
    plus_advance: false,
    custom_branding: false
  }
};

const LicenseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [license, setLicense] = useState<LicenseData | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshLicense = () => {
    setLoading(true);
    setTimeout(() => {
      const stored = localStorage.getItem('kasaku_license');
      if (stored) {
        setLicense(JSON.parse(stored));
      } else {
        setLicense(MOCK_LICENSE);
        localStorage.setItem('kasaku_license', JSON.stringify(MOCK_LICENSE));
      }
      setLoading(false);
    }, 800);
  };

  const updateAddon = (key: keyof Addons, value: boolean) => {
    if (!license) return;
    const newLicense = { ...license, addons: { ...license.addons, [key]: value } };
    setLicense(newLicense);
    localStorage.setItem('kasaku_license', JSON.stringify(newLicense));
  };

  const extendLicense = () => {
    if (!license) return;
    const newLicense = { ...license, days_left: 30, status: 'OK' as const };
    setLicense(newLicense);
    localStorage.setItem('kasaku_license', JSON.stringify(newLicense));
  }

  useEffect(() => { refreshLicense(); }, []);

  return (
    <LicenseContext.Provider value={{ license, loading, refreshLicense, updateAddon, extendLicense }}>
      {children}
    </LicenseContext.Provider>
  );
};

// --- LAYOUT & APP ---

const Sidebar: React.FC<{ mobileOpen: boolean, setMobileOpen: (open: boolean) => void }> = ({ mobileOpen, setMobileOpen }) => {
  const location = useLocation();
  const { license } = useLicense();

  const navItems: NavItem[] = [
    { id: 'dashboard', label: 'Dasbor Eksekutif', icon: <LayoutDashboard size={20} />, path: '/' },
    { id: 'transaksi', label: 'Transaksi', icon: <ArrowRightLeft size={20} />, path: '/transaksi' },
    { id: 'faktur', label: 'Faktur & Invoice', icon: <Receipt size={20} />, path: '/faktur' },
    { id: 'crm', label: 'Manajemen Klien', icon: <Users size={20} />, path: '/crm', addonRequired: 'plus_advance' },
    { id: 'proyek', label: 'Proyek & Tugas', icon: <Briefcase size={20} />, path: '/proyek', addonRequired: 'plus_advance' },
    { id: 'kalender', label: 'Kalender', icon: <Calendar size={20} />, path: '/kalender', addonRequired: 'plus_advance' },
    { id: 'produksi', label: 'Manufaktur', icon: <Factory size={20} />, path: '/manufaktur', addonRequired: 'manufacturing' },
    { id: 'resto', label: 'Restoran', icon: <Utensils size={20} />, path: '/restoran', addonRequired: 'restaurant' },
    { id: 'profil', label: 'Profil & Langganan', icon: <User size={20} />, path: '/profil' },
    { id: 'pengaturan', label: 'Pengaturan', icon: <Settings size={20} />, path: '/pengaturan' },
  ];

  const visibleItems = navItems.filter(item => {
    if (!item.addonRequired) return true;
    return license?.addons[item.addonRequired];
  });

  return (
    <>
      {mobileOpen && ( <div className="fixed inset-0 z-20 bg-black bg-opacity-50 md:hidden" onClick={() => setMobileOpen(false)} /> )}
      <aside className={`fixed inset-y-0 left-0 z-30 w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out ${mobileOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 no-print`}>
        <div className="h-16 flex items-center px-6 border-b border-gray-100">
          <div className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-orange-500">Kasaku</div>
        </div>
        <nav className="p-4 space-y-1 overflow-y-auto h-[calc(100vh-4rem)]">
          {visibleItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link key={item.id} to={item.path} onClick={() => setMobileOpen(false)} className={`flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-colors ${isActive ? 'bg-blue-50 text-blue-700' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'}`}>
                {item.icon} {item.label}
              </Link>
            );
          })}
        </nav>
      </aside>
    </>
  );
};

const Header: React.FC<{ toggleMobile: () => void }> = ({ toggleMobile }) => {
  const { license, extendLicense } = useLicense();
  const { userProfile } = useData();
  const showWarning = license && license.days_left <= 7 && license.days_left > 0;

  // Initials for avatar
  const initials = userProfile.companyName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();

  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4 sm:px-6 z-10 no-print">
      <button onClick={toggleMobile} className="p-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-md md:hidden"><Menu size={24} /></button>
      <div className="flex-1 flex justify-end items-center gap-4">
        {showWarning && (
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-orange-50 text-orange-700 rounded-full text-xs font-medium border border-orange-200">
            <AlertTriangle size={14} />
            <span>Lisensi berakhir dalam {license.days_left} hari</span>
            <button onClick={extendLicense} className="ml-2 text-orange-800 underline hover:text-orange-900 font-bold">Perpanjang</button>
          </div>
        )}
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <div className="text-sm font-semibold text-gray-900">{userProfile.companyName}</div>
            <div className="text-xs text-gray-500">{license?.plan} Plan</div>
          </div>
          <div className="h-9 w-9 rounded-full overflow-hidden shadow-sm border border-gray-200">
            {userProfile.avatar ? (
              <img src={userProfile.avatar} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-gradient-to-tr from-blue-500 to-orange-400 flex items-center justify-center text-white font-bold">
                {initials}
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

const LockScreen: React.FC = () => {
  const { license, extendLicense } = useLicense();
  if (!license) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900 bg-opacity-95 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 text-center">
        <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-6"><Lock className="w-8 h-8 text-red-600" /></div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Akses Terkunci</h2>
        <p className="text-gray-600 mb-6">{license.status === 'EXPIRED' || license.days_left <= 0 ? 'Masa aktif langganan habis.' : 'Akun ditangguhkan.'}</p>
        <button onClick={extendLicense} className="w-full py-3 px-4 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700">Perpanjang Langganan</button>
      </div>
    </div>
  );
};

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { license, loading } = useLicense();
  const location = useLocation();

  if (loading) return <div className="flex h-screen items-center justify-center bg-gray-50"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div></div>;
  const isLocked = license && (license.status !== 'OK' || license.days_left <= 0);
  if (location.pathname.startsWith('/print/')) return <div className="bg-white min-h-screen">{children}</div>;

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {isLocked && <LockScreen />}
      <Sidebar mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className="flex-1 flex flex-col min-w-0">
        <Header toggleMobile={() => setMobileOpen(!mobileOpen)} />
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 relative">{children}</main>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <MemoryRouter>
      <LicenseProvider>
        <DataProvider>
          <Layout>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/transaksi" element={<Transactions />} />
              <Route path="/faktur" element={<Invoices />} />
              <Route path="/print/invoice/:id" element={<InvoicePrint />} />
              <Route path="/print/receipt/:id" element={<ReceiptPrint />} />
              <Route path="/profil" element={<Profile />} />
              <Route path="/pengaturan" element={<SettingsPage />} />
              <Route path="/manufaktur" element={<Manufacturing />} />
              <Route path="/restoran" element={<Restaurant />} />
              <Route path="/crm" element={<CRM />} />
              <Route path="/proyek" element={<Projects />} />
              <Route path="/kalender" element={<CalendarPage />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </Layout>
        </DataProvider>
      </LicenseProvider>
    </MemoryRouter>
  );
};

export default App;